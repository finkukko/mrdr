import os

base_path = r"C:\Users\lelum\Desktop\Mii\Bodymodel\Bodytops"
output_file = os.path.join(base_path, "names.txt")

# Check if base_path exists
if not os.path.exists(base_path):
    print(f"Error: The directory {base_path} does not exist.")
else:
    commands = []

    # Iterate over the files in the base path
    for file_name in os.listdir(base_path):
        file_path = os.path.join(base_path, file_name)
        
        # Ensure it's a file and not a directory
        if os.path.isfile(file_path):
            # Get the file name without extension
            name_without_extension = os.path.splitext(file_name)[0]
            commands.append(name_without_extension)

    if commands:
        # Write the names to the output file
        with open(output_file, "w") as f:
            for command in commands:
                f.write(command + "\n")
        print(f"File written to {output_file}")
    else:
        print("No files found to process.")
